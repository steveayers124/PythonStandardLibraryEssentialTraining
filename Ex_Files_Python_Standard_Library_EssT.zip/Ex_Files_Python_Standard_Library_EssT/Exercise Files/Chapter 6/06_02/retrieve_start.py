# retrieve data from the internet
import urllib.request


sample_url = "http://httpbin.org/xml"

# TODO: Create a request to retrieve data using urllib.request


# TODO: Check the status
status_code = 0


# TODO: if no error, then read the response contents
if status_code >= 200 and status_code < 300:
    # TODO: work with response headers
    pass

    # TODO: read the data from the URL
    pass
