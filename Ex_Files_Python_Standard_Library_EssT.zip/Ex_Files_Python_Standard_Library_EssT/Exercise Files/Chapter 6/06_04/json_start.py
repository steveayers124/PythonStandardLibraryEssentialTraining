# working with JSON data
import urllib.request
import json


# TODO: use urllib to retrieve some sample JSON data


# TODO: use the JSON module to parse the returned data


# TODO: when the data is parsed, we can access it like any other object


# TODO: python objects can also be written out as JSON
objdata = {
    "name": "Joe Marini",
    "author": True,
    "titles": [
        "Learning Python", "Advanced Python", "Python Standard Library Essential Training"
    ]
}
