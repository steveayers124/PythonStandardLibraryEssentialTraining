# Use standard library functions to search strings for content


sampleStr = "The quick brown fox jumps over the lazy dog"

# TODO: startsWith and endsWith functions


# TODO: the find and rfind functions


# TODO: using replace


# TODO: counting instances of substrings
