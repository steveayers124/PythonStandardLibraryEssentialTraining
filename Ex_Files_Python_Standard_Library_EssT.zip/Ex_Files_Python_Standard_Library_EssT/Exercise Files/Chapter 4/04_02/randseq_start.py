# Functions for generating random data sequences
import random
import string

# TODO: Use the choice function to randomly select from a sequence
moves = ["rock", "paper", "scissors"]


# TODO: Use the choices function to create a list of random elements
roulette_wheel = ["black", "red", "green"]


# TODO: The sample function randomly selects elements from a population
# without replacement (the chosen items are not replaced)


# TODO: The shuffle function shuffles a sequence in place
players = ["Bill", "Jane", "Joe", "Sally", "Mike", "Lindsay"]


# TODO: to shuffle an immutable sequence, use the sample function first
