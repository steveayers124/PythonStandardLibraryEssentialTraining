# Create a temporary password using Python
import secrets
import string


# TODO: Function to return a temporary password given a length
def generateTempPass(numChars=8):
    pass


# TODO: Function to return a temporary password and enforce 1 number and 1 uppercase
def generateBetterPass(numChars=8):
    pass

# create a temporary password
# print(generateTempPass(10))

# create a stronger temporary password
# print(generateBetterPass(10))


# TODO: create a temporary, hard-to-guess URL
resultUrl = "https://my.example.com?reset="
