# demonstrate using the random module to create random numbers
import random

# TODO: create a random number


# TODO: implement a coin toss function


# TODO: get a random number within a range


# TODO: generate random integers within a given range


# TODO: generate random integers with a step function
# this example chooses from 0 to 100 stepped by 5


# TODO: Use the seed function to position the generator

print("----------------")
