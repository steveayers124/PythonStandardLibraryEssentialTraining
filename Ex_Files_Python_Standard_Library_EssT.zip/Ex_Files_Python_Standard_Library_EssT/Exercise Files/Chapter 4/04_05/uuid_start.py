# Generating unique identifiers
import uuid


# TODO: use the uuid4 function to create a random sequence using
# the underlying os.urandom() function

print("~~~~~~~~~~~~~~~~~~~~~~~\n")


# TODO: create a UUID using uuid5, which takes a namespace and
# name value. Note that this version is not crypto-safe

print("~~~~~~~~~~~~~~~~~~~~~~~\n")
