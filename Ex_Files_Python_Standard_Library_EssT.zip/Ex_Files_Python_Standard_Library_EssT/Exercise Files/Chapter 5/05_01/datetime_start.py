# Basics of dates and times
from datetime import date, time, datetime


# TODO: create a new date object


# TODO: create a new time object


# TODO: create a new datetime object


# TODO: access various components of the date and time objects


# TODO: To modify values of date and time objects, use the replace function

# print(d1)
# print(t1)
# print(dt1)
