# Perform calculations with dates and times using timedelta
import datetime

# create some date objects
dt1 = datetime.datetime(2019, 1, 15, 10)
dt2 = datetime.datetime(2019, 1, 20, 15)

# TODO: dates and times can be compared


# TODO: Subtracting one date from another creates a timedelta

# timedeltas have components


# TODO: timedeltas can be used to perform date math
now = datetime.datetime.now()

# print("One year from now will be: ")
# print("One week from now will be: ")
# print("One week ago was: ")
