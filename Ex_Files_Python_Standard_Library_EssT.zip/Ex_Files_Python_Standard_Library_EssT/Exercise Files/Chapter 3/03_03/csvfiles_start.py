# Reading and writing Comma Separate Values files with Python
import csv


# TODO: list the dialects that are available to use


# TODO: Open a CSV file and read each row of data
def readerSample():
    pass


# TODO: Use the CSV module Sniffer to see what dialect of CSV this is
def useSniffer():
    pass


# TODO: Write data to a CSV file
def writerSample():
    pass


# Exercise the samples
# readerSample()
# writerSample()
# useSniffer()
