# Basic file operations in Python


# TODO: open a file for writing data
# "w" means write, "r" means read, "a" means append, "r+" means read and write


# TODO: read a file's data


# TODO: Add data to an existing file
