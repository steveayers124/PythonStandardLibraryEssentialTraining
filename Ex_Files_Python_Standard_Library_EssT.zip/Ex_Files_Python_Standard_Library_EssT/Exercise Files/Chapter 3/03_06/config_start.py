# read the contents of configuration files
import configparser


# TODO: Create the configuration parser


# TODO: Read the configuration file


# TODO: print the sections


# TODO: Access one of the default values


# TODO: Demonstrate the getXXX convenience functions


# TODO: Access a non-existent value

