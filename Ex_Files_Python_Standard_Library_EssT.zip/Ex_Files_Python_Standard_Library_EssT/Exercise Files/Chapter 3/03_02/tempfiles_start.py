# Working with temporary files
import os
import tempfile

# TODO: get information about the temp data environment


# TODO: create a temporary file using mkstemp()


# TODO: create a temp file using the TemporaryFile class


# TODO: create a temporary directory using the TemporaryDirectory class
